package com.btcoin.service.impl;

import java.io.IOException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.NoHttpResponseException;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.log4j.Logger;
import org.jsoup.Jsoup;

import com.btcoin.common.JredisManager;
import com.btcoin.common.Resp;
import com.btcoin.common.ResultConstant;
import com.btcoin.common.SimpleHostnameVerifier;
import com.btcoin.common.SimpleTrustManager;
import com.btcoin.common.VerifyUtils;
import com.btcoin.service.BtcWeb;

/**
 * btcchina
 * @author Administrator
 *
 */
public class BtcchinaWeb implements BtcWeb{

	private static final Logger log = Logger.getLogger(BtcchinaWeb.class);
	private static final String login_url = "https://vip.btcchina.com/bbs/ucp.php?mode=login&change_lang=zh_cmn_hans";
	private static final String buyOrder_url = "https://vip.btcchina.com/trade/buy";
	private static final String sellOrder_url = "https://vip.btcchina.com/bbs/ucp.php?mode=login";
	private static final String cancelOrder_url = "https://vip.btcchina.com/bbs/ucp.php?mode=login";
	private static final String getMarketDepth_url = "https://vip.btcchina.com/bbs/ucp.php?mode=login";
	private static final String getOrders_url = "https://vip.btcchina.com/bbs/ucp.php?mode=login";
	public static final String redisKey = "btcchina";
	
	/**
	 * 无SSL认证
	 */
	protected void initSSL() {
        try {
            TrustManager[] tmCerts = new javax.net.ssl.TrustManager[1];
            tmCerts[0] = new SimpleTrustManager();
            javax.net.ssl.SSLContext sc = javax.net.ssl.SSLContext.getInstance("SSL");
            sc.init(null, tmCerts, null);
            javax.net.ssl.HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HostnameVerifier hv = new SimpleHostnameVerifier();
            HttpsURLConnection.setDefaultHostnameVerifier(hv);
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	private CloseableHttpClient getHttpClient() {
		return getHttpClient(new BasicCookieStore());
	}
	private CloseableHttpClient getHttpClient(BasicCookieStore cookieStore) {
		try{
			SSLContext sslContext = SSLContext.getInstance("SSL");
			sslContext.init(null,new TrustManager[]{ new X509TrustManager() {
				
				@Override
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					// TODO Auto-generated method stub
					return null;
				}
				
				@Override
				public void checkServerTrusted(java.security.cert.X509Certificate[] chain,
						String authType) throws CertificateException {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void checkClientTrusted(java.security.cert.X509Certificate[] chain,
						String authType) throws CertificateException {
					// TODO Auto-generated method stub
					
				}
			}},new SecureRandom());
	
	        return HttpClients.custom().setSSLSocketFactory(new SSLSocketFactory(sslContext)).setDefaultCookieStore(cookieStore).build();
		}catch(Exception err){
			log.error("创建SSL HttpClient异常:",err);
			return HttpClients.custom().setDefaultCookieStore(cookieStore).build();
		}
	}
	
	
	@Override
	public boolean login(final String username, String password) throws IOException {
		
		final BasicCookieStore cookieStore = new BasicCookieStore();
		CloseableHttpClient httpclient= this.getHttpClient(cookieStore);
		try {
			List <NameValuePair> nvps = new ArrayList <NameValuePair>();
			nvps.add(new BasicNameValuePair("username", username));  
			nvps.add(new BasicNameValuePair("password", password));  
			//nvps.add(new BasicNameValuePair("kf5", "0"));
			nvps.add(new BasicNameValuePair("login", ""));
			nvps.add(new BasicNameValuePair("redirect", "/")); 
			//nvps.add(new BasicNameValuePair("sid", "123fa9843e6e2d92afd9bf00c3e45776")); 
			//nvps.add(new BasicNameValuePair("time", "0"));
			
			HttpPost httpPost = new HttpPost( login_url );
			httpPost.setEntity(new UrlEncodedFormEntity(nvps)); 
			httpPost.setHeader("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"); 
			httpPost.setHeader("Accept-Encoding","gzip, deflate"); 
			httpPost.setHeader("Accept-Language","zh-cn,zh;q=0.8,en-us;q=0.5,en;q=0.3"); 
			httpPost.setHeader("Connection","keep-alive"); 
			httpPost.setHeader("Cookie","Hm_lvt_4b4a9e41d8a28c344a964dfa3baf4f6d=1386908362,1387156187,1387246322,1387345399; _ga=GA1.2.1334210409.1386908364; style_cookie=null; visid_incap_88065=3EulVzKxSfiytppzmpoDkuiyr1IAAAAAQUIPAAAAAACY0AtAv9QbHq3EPSLQ4uIZ; PHPSESSID=ohs8gk2n375igkhe6trb2115o0; Hm_lpvt_4b4a9e41d8a28c344a964dfa3baf4f6d=1387345399"); 
			httpPost.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0 ");  
			httpPost.setHeader("Host","vip.btcchina.com");  
			httpPost.setHeader("Referer","https://vip.btcchina.com/");  
			
			return httpclient.execute(httpPost, new ResponseHandler<Boolean>() {
				@Override
				public Boolean handleResponse(HttpResponse arg0)
						throws ClientProtocolException, IOException {
					CloseableHttpResponse response = (CloseableHttpResponse)arg0;
					try{
						StatusLine status = response.getStatusLine();  
				        if (status.getStatusCode() > 302) {  
				            throw new NoHttpResponseException(  
				                    "Did not receive successful HTTP response: status code = "  
				                            + status.getStatusCode() + ", status message = ["  
				                            + status.getReasonPhrase() + "]");  
				        }else{
							Header[] locations = response.getHeaders("Location");
							if( locations.length == 0 ){
								log.error("Login failed.");
								return false;
							}
							log.info("Login form get: " + response.getStatusLine());
			                //EntityUtils.consume(entity);

							log.info("Post logon cookies:");
			                List<Cookie> cookies = cookieStore.getCookies();
			                if (cookies.isEmpty()) {
			                	log.info("None");
			                } else {
				                //保存用户cookies 到redis
				                JredisManager redisManager = JredisManager.getInstance();
				                redisManager.getJedis().hset(redisKey, String.format("user:%s:cookies", username),JSONArray.fromObject(cookies).toString());
			                	
				                log.info("save cookies to redis successful.");
			                	for (int i = 0; i < cookies.size(); i++) {
			                    	log.info("- " + cookies.get(i).toString());
			                    }
			                }
				        }
				        return true;
					}finally{
						response.close();
					}
				}
			});
		}finally{
			httpclient.close();
		}
	}

	@Override
	public Resp buyOrder(double price, double amount,JSONObject params) throws IOException {
		if( !VerifyUtils.verifyUser$Password(params) ){
			return new Resp(ResultConstant.FAILURE, "User name password cannot be empty.");
		}
		CloseableHttpClient httpclient = this.getHttpClient();
		HttpPost httpPost = new HttpPost(buyOrder_url);
		try{
			List<NameValuePair> nvps = new ArrayList <NameValuePair>();  
			nvps.add(new BasicNameValuePair("amount", amount+""));  
			nvps.add(new BasicNameValuePair("no_csrf_buybtc", "4f35ea956f3ad705d58cc63794ac126a"));  
			nvps.add(new BasicNameValuePair("ordertype", "market"));  
			nvps.add(new BasicNameValuePair("price", price+"")); 
			nvps.add(new BasicNameValuePair("tradepwd", "123456789")); 
			httpPost.setEntity(new UrlEncodedFormEntity(nvps));
			
			httpPost.setHeader("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"); 
			httpPost.setHeader("Accept-Encoding","gzip, deflate"); 
			httpPost.setHeader("Accept-Language","zh-cn,zh;q=0.8,en-us;q=0.5,en;q=0.3"); 
			httpPost.setHeader("Connection","keep-alive"); 
			httpPost.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0");  
			httpPost.setHeader("Host","vip.btcchina.com");  
			httpPost.setHeader("Referer",buyOrder_url);
			
			final String username = params.getString("username");
			final String password = params.getString("password");
			
			//读取redis用户Cookie
			JredisManager redisManager = JredisManager.getInstance();
			String data = redisManager.getJedis().hget("btcchina", "user:btcchinatest:cookies");
			if( data != null ){
		        JSONArray cookies = JSONArray.fromObject(data);
		        String cookieHeader = "";
		        for (Object obj : cookies) {
					JSONObject cookie = (JSONObject) obj;
					cookieHeader += (cookie.getString("name")+"="+cookie.getString("value"))+";";
				}
		        httpPost.setHeader("Cookie",cookieHeader);
			}
			return httpclient.execute(httpPost, new ResponseHandler<Resp>() {
				@Override
				public Resp handleResponse(HttpResponse arg0) throws ClientProtocolException, IOException {
					CloseableHttpResponse response = (CloseableHttpResponse)arg0;
					try{
						StatusLine status = response.getStatusLine();  
				        if (status.getStatusCode() >= 302) {
				        	log.info("用户cookie已过期请重新登录。");
				        	return new Resp(ResultConstant.RELOGIN,"用户cookie已过期请重新登录。");
				        }
						
						HttpEntity entity = response.getEntity();
						Scanner scanner = new Scanner(entity.getContent());
						StringBuilder htmlDocument = new StringBuilder();
						while( scanner.hasNext() ){
							htmlDocument.append(new String(scanner.nextLine().getBytes(),"utf-8"));
						}
						
					}finally{
						response.close();
					}
					return new Resp(ResultConstant.SUCCESS,"Buy success");
				}
			});
		}finally{
			httpclient.close();
		}
	}

	@Override
	public Resp sellOrder(double price, double amount,JSONObject params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Resp cancelOrder(long id,JSONObject params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Resp getMarketDepth(long limit,JSONObject params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Resp getOrders(double openOnly,JSONObject params) {
		// TODO Auto-generated method stub
		return null;
	}

}
