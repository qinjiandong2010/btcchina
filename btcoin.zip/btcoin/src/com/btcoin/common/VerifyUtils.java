package com.btcoin.common;

import com.btcoin.utils.StringUtil;

import net.sf.json.JSONObject;

public class VerifyUtils {

	public static boolean verifyUser$Password(JSONObject object){
		if(StringUtil.isJSONObjectOk(object,"username") && StringUtil.isJSONObjectOk(object,"password")){
			return true;
		}
		return false;
	}
}
