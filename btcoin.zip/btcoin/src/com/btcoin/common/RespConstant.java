package com.btcoin.common;

public class RespConstant {
	public static String DEFAULT_PAGENO		="1";
	public static String DEFAULT_PAGESIZE	="10";
	public static String TOKEN				="token";
	public static String PARAM				="param";
	public static String RESULT				="result";
	public static String SUMMARY			="message";
	public static String ACCESSID			="accessid";
	public static String ACCESSKEY			="accesskey";
	public static String QUERY_CONDITIONS	="params";
	public static String BODY				="return";
	public static String DATA_LIST			="data";
	public static String CONDITION_PAGENO	="pageno";
	public static String CONDITION_PAGESIZE	="pagesize";
	public static String CONDITION_TOTALPAGES="totalpages";
	public static String CONDITION_TOTALROWS	="totalrows";
	
	
	
	
	//below added by Flying Begin on [2012-06-15]
	public static String RESULT_CODE="result";
	public static String RETURN_DATA="return";
	public static String MESSAGE_INFO="message";
	public static String SUCCESS="SUCCESS";
	public static String FAILURE="FAILURE";
	public static String EXIST = "EXIST";
	//Above added by Flying end on [[2012-06-15]]

}
