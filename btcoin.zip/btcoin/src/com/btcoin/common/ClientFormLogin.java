package com.btcoin.common;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

import com.btcoin.common.HttpComponentsClientExecutor.HttpMethod;

public class ClientFormLogin {
	
		public static void test() throws IOException{
			BasicCookieStore cookieStore = new BasicCookieStore();
	        CloseableHttpClient httpclient = HttpClients.custom().setDefaultCookieStore(cookieStore).build();
	        try{
				List <NameValuePair> nvps = new ArrayList <NameValuePair>();  
				nvps.add(new BasicNameValuePair("username", "btcchinatest"));  
				nvps.add(new BasicNameValuePair("password", "123456789"));  
				nvps.add(new BasicNameValuePair("kf5", "0"));  
				nvps.add(new BasicNameValuePair("login", "��¼"));  
				nvps.add(new BasicNameValuePair("redirect", "index.php")); 
				nvps.add(new BasicNameValuePair("sid", "d0a575738ca0330fcab463ccd1824b11")); 
				nvps.add(new BasicNameValuePair("time", "0")); 
				
				HttpPost httpPost = new HttpPost( "https://vip.btcchina.com/bbs/ucp.php?mode=login" );  
				httpPost.setEntity(new UrlEncodedFormEntity(nvps)); 
				httpPost.setHeader("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"); 
				httpPost.setHeader("Accept-Encoding","gzip, deflate"); 
				httpPost.setHeader("Accept-Language","zh-cn,zh;q=0.8,en-us;q=0.5,en;q=0.3"); 
				httpPost.setHeader("Connection","keep-alive"); 
				httpPost.setHeader("Cookie","Hm_lvt_4b4a9e41d8a28c344a964dfa3baf4f6d=1386908362; Hm_lpvt_4b4a9e41d8a28c344a964dfa3baf4f6d=1386912079; _ga=GA1.2.1334210409.1386908364; style_cookie=null; phpbb3_ja5fa_u=1; phpbb3_ja5fa_k=; phpbb3_ja5fa_sid=d0a575738ca0330fcab463ccd1824b11; PHPSESSID=hcejpctoeihsp6e6k1qocmbf26"); 
				httpPost.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0 ");  
				httpPost.setHeader("Host","vip.btcchina.com");  
				httpPost.setHeader("Referer","https://vip.btcchina.com/");  
				//httpPost.setHeader("Cookie", cookie);  
				HttpResponse response = httpclient.execute(httpPost);  
				HttpEntity entity = response.getEntity();
				Scanner scanner = new Scanner(entity.getContent());
				while( scanner.hasNext() ){
					System.out.println(new String(scanner.nextLine().getBytes(),"utf-8"));
				}
				System.out.println(Arrays.toString(response.getAllHeaders()));
				System.out.println("Login form get: " + response.getStatusLine());
                EntityUtils.consume(entity);

                System.out.println("Post logon cookies:");
                List<Cookie> cookies = cookieStore.getCookies();
                if (cookies.isEmpty()) {
                    System.out.println("None");
                } else {
                    for (int i = 0; i < cookies.size(); i++) {
                        System.out.println("- " + cookies.get(i).toString());
                    }
                }
                /**
                 * amount	1.000
					buy	����
					no_csrf_buybtc	74e17af335a81d3ecee0a9868c0170cb
					ordertype	market
					price	5205.10
					tradepwd	123456789
                 * 
                 */
                
                httpPost = new HttpPost("https://vip.btcchina.com/trade/buy");
                httpPost.setEntity(new UrlEncodedFormEntity(nvps)); 
				httpPost.setHeader("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"); 
				httpPost.setHeader("Accept-Encoding","gzip, deflate"); 
				httpPost.setHeader("Accept-Language","zh-cn,zh;q=0.8,en-us;q=0.5,en;q=0.3"); 
				httpPost.setHeader("Cookie","Hm_lvt_4b4a9e41d8a28c344a964dfa3baf4f6d=1386908362,1387156187; _ga=GA1.2.1334210409.1386908364; style_cookie=null; PHPSESSID=cuuj9a0n9vjh2rfqrm9mumro12; Hm_lpvt_4b4a9e41d8a28c344a964dfa3baf4f6d=1387157387; phpbb3_ja5fa_u=352258; phpbb3_ja5fa_k=; phpbb3_ja5fa_sid=1966e6481c28b9c5e06631375f4e2866");
				httpPost.setHeader("Connection","keep-alive"); 
				httpPost.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0");  
				httpPost.setHeader("Host","vip.btcchina.com");  
				httpPost.setHeader("Referer","	https://vip.btcchina.com/trade/buy");
				nvps = new ArrayList <NameValuePair>();  
				nvps.add(new BasicNameValuePair("amount", "1"));  
				nvps.add(new BasicNameValuePair("buy", "����"));  
				nvps.add(new BasicNameValuePair("no_csrf_buybtc", "0582110a7ffeb9e9c5783043cbf825b1"));  
				nvps.add(new BasicNameValuePair("ordertype", "market"));  
				nvps.add(new BasicNameValuePair("price", "5205.10")); 
				nvps.add(new BasicNameValuePair("tradepwd", "123456789")); 
				httpPost.setEntity(new UrlEncodedFormEntity(nvps));
				
				response = httpclient.execute(httpPost);  
				
				System.out.println(Arrays.toString(httpPost.getAllHeaders()));
				entity = response.getEntity();
				scanner = new Scanner(entity.getContent());
				while( scanner.hasNext() ){
					System.out.println(new String(scanner.nextLine().getBytes(),"utf-8"));
				}
                
	        }finally {
	            httpclient.close();
	        }
		}

	    public static void main(String[] args) throws Exception {
	    	test();
	       /* BasicCookieStore cookieStore = new BasicCookieStore();
	        CloseableHttpClient httpclient = HttpClients.custom().setDefaultCookieStore(cookieStore).build();
	        try {
	        	HttpParams params = httpclient.getParams();  
	        	params.setParameter(ClientPNames.HANDLE_REDIRECTS, false);
	        	
	            HttpPost httpost = new HttpPost("http://localhost:8081/login.html");
	            List <NameValuePair> nvps = new ArrayList <NameValuePair>();
	            nvps.add(new BasicNameValuePair("userName", "spadmin"));
	            nvps.add(new BasicNameValuePair("password", "123456"));
	            httpost.setEntity(new UrlEncodedFormEntity(nvps, Consts.UTF_8));

	            CloseableHttpResponse response2 = httpclient.execute(httpost);
	            try {
	                HttpEntity entity = response2.getEntity();
 
	                System.out.println("Login form get: " + response2.getStatusLine());
	                EntityUtils.consume(entity);

	                System.out.println("Post logon cookies:");
	                List<Cookie> cookies = cookieStore.getCookies();
	                if (cookies.isEmpty()) {
	                    System.out.println("None");
	                } else {
	                    for (int i = 0; i < cookies.size(); i++) {
	                        System.out.println("- " + cookies.get(i).toString());
	                    }
	                }
	                
	            } finally {
	                response2.close();
	            }
	        } finally {
	            httpclient.close();
	        }*/
	    }
}

