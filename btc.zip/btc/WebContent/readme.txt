1.安装redis：
  --BTC API使用redis作为数据存储，请确保安装redis key-value内存数据库。
  --下载地址：http://redis.io/download
    
2.修改配置config.properties